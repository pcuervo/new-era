=== Hero Plugin ===
Contributors: HeroPlugins
Tags: Hero Plugin
Requires at least: 3.3
Tested up to: 4.1
Stable Tag: 0.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Enter your description here

== Usage ==
1. Upload `hplugin` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 0.0.0 =
* Plugin Core Framework Generated