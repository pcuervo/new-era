//FRONTEND SCRIPT

//initialise frontend
function hutility_initialise_frontend(unique_name){
	//log the default object
	var object = eval("hutility_default_object_"+ unique_name +"");
	console.log(object);
}